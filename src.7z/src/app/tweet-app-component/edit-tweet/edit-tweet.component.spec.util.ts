export const tweetData = {
    id: '628e1354ef68492b2db3b2ff',
    email: 'neeraja.uppalapati@gmail.com', 
    tweetMsg: 'kkk', 
    time: '05/25/2022 5:00:28', 
    like: 0,
    tagText: "",
    replyTweet: []
}
export const updateTweetMSgSuccessfully = {
    email: "neeraja.uppalapati@gmail.com",
    id: "628e1354ef68492b2db3b2ff",
    like: 0,
    replyTweet: [],
    tagText: "",
    time: "06/09/2022 5:39:45",
    tweetMsg: "kkkk"
}