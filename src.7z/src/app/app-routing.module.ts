import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.gard';
import { HomeComponentComponent } from './tweet-app-component/home-component/home-component.component';
import { UserLoginComponent } from './tweet-app-component/user-login/user-login.component';
import { UserRegisterComponent } from './tweet-app-component/user-register/user-register.component';
import { UserTweetsComponent } from './tweet-app-component/user-tweets/user-tweets.component';

const routes: Routes = [
  {path:'home', component:HomeComponentComponent, canActivate: [AuthGuard]},
  {path:'userTweets', component:UserTweetsComponent, canActivate: [AuthGuard] },
  {path:'login', component:UserLoginComponent},
  {path:'register', component:UserRegisterComponent},
  {path:'', redirectTo:"/login", pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
