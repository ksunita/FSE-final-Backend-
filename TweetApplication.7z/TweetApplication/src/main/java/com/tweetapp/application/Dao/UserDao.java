package com.tweetapp.application.Dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetapp.application.model.User;

public interface UserDao extends MongoRepository<User, Long>{
	User findByEmail(String email);
}
