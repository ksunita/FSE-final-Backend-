package com.tweetapp.application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tweetapp.application.Dao.TweetDao;
import com.tweetapp.application.model.Tweet;

@Service @Transactional
public class TweetServiceImpl implements TweetService{
	
	@Autowired
	private TweetDao tweetDao;

	
	@Override
	public List<Tweet> getAllTweets() {
		System.out.println(tweetDao.findAll());
		return tweetDao.findAll();
	}

	@Override
	public List<Tweet> getUserTweets(String email) {
		System.out.println("Service in=mpl");
		System.out.println(email);
		System.out.println(tweetDao.findByEmail(email));
		return tweetDao.findByEmail(email);
	}

	@Override
	public Tweet save(Tweet tweet) {
		System.out.println(tweet);
		tweetDao.save(tweet);
		return tweet;
	}

	@Override
	public Tweet updateTweet(Tweet tweet) {
		Tweet temp = tweetDao.findById(String.valueOf(tweet.getId()));
		temp.setTweetMsg(tweet.getTweetMsg());
		temp.setTime(tweet.getTime());
		tweetDao.save(temp);
		return temp;
	}

	@Override
	public void deleteTweet(Tweet tweet) {
		tweetDao.deleteById(tweet.getId());
	}

	@Override
	public Tweet likeTweet(String id) {
		Tweet temp = tweetDao.findById(id);
		int likes = temp.getLike();
		temp.setLike(likes +1);
		tweetDao.save(temp);
		return temp;
	}

	@Override
	public Tweet replyTweet(Tweet retweet, String tweetId) {
		String TweetId = tweetId;
		Tweet temp = tweetDao.findById(TweetId);
		List<Tweet> replyTweets = temp.getReplyTweet();
		retweet.setId(String.valueOf(replyTweets.size()+1));
		replyTweets.add(retweet);
		temp.setReplyTweet(replyTweets);
		tweetDao.save(temp);
		return temp;
		
	}

}
